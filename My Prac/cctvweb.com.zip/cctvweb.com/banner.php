<style>


#banner{
width:985px;
height:150px;
position:absolute;

}
</style>



    <div id="banner">
    <img src="images/logo.jpg" height="100" width="200">
 </div>
<div style="position:relative;">    
<p align="right"><a href="logout.php"><b>Logout</b></a></p>
</div>    