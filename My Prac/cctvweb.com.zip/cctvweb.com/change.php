<?php 
	include_once("function.php");
	
	
	if(!isset($_SESSION['registered']))
	{
		header("Location: index.php");
	}
	
	if(isset($_SESSION['user_registerd']))
	{
		echo '<p style="color:red;">Thank you</p>';
		unset($_SESSION['user_registerd']);
	}
?>
<h1>Change Password:</h1>
<form action='changepassword.php' method='POST'>
	<table>
		<tbody>
			<tr>
				<td>Email Address</td><td><input type='text' name='email' /></td>
			</tr>
            <tr>
				<td>Current Password: </td><td><input type='text' name='curPass' /></td>
			</tr>
			<tr>
				<td>New Password: </td><td><input type='text' name='newPass' /></td>
			</tr>
			<tr>
				<td>New Password: </td><td><input type='text' name='cnewPass' /></td>
			</tr>
			
            <tr>
				<td></td><td><input type='submit' value='Change Password' name='changePass' /></td>
			</tr>
		</tbody>
	</table>
</form>
