<style>
#footer{
width:990px;
height:150px;
position:absolute;
background-color:green;
}
</style>

    <div id="footer">
    <img src="images/footer.png" width="990" height="150">
    </div>
    
    