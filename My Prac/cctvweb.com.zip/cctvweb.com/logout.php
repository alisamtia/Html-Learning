<?php 
		include_once("function.php");
		
unset($_SESSION['registered']);
unset($_SESSION['newuser']);



header("Location: signup.php");
	