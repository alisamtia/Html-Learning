<?php

include_once("function.php");
	


if(!isset($_SESSION['newuser']))
	{
		header("Location: signup.php");
	}

if(!isset($_SESSION['registered']))
	{
		header("Location: signup.php");
	}

?>




<!DOCTYPE>
<head>
<style>
#maindiv
{
width:990px;
height:1000px;

margin-left:auto;
margin-right:auto;
position:relative;
}
#banner{
width:980px;
height:150px;
position:absolute;

}

#menu{
width:740px;
height:40px;
position:absolute;

margin-top:40px;
margin-left:230px;
}


#slider{
width:990px;
height:400px;
position:absolute;
margin-top:120px;
}



#products
{
width:990px;
height:800px;
text-align:justify;
position:absolute;
margin-top:560px;
}






#footer
{
width:990px;
height:200px;
position:absolute;
margin-top:1150px;
margin-left:px;
background-color:brown;
}

</style>





<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <title>Amazing Slider</title>
    
    <!-- Insert to your webpage before the </head> -->
    <script src="sliderengine/jquery.js"></script>
    <script src="sliderengine/amazingslider.js"></script>
    <script src="sliderengine/initslider-1.js"></script>
    <!-- End of head section HTML codes -->
    


</head>

<body>
<div id="maindiv">
	
    <div id="banner">
    <?php
	include("banner.php");
        
    ?>
    </div>
    	<div id="menu">
        <?php
	
include("menu.php");
    ?>
    
    	</div>
        
        <div id="slider">
        

<?php
	include("slider.html");
    ?>
    
    
    	</div>




<div id="products">


<table border="1" width="990" height="550" align="center" cellspacing="15" bgcolor="black">
<tr>
<td height="200"><img src="images/indoor.jpg" width="220" height="190"></td>
<td height="200"><img src="images/out door.jpg" width="220" height="190"></td>
<td height="200"><img src="images/IR Day-Night Camera.jpg" width="220" height="190"></td>
<td height="200"><img src="images/Vandal Proof Camera.jpg" width="220" height="190"></td>
</tr>


<tr>
<td align="center"><font color="white"><b>Indoor Camera</b></font></td>
<td align="center"><font color="white"><b>Out Door Camera</b></font></td>
<td align="center"><font color="white"><b>IR Day-Night Camera</b></font></td>
<td align="center"><font color="white"><b>Vandal Proof Camera</b></font></td>
</tr>


<tr>
<td height="200"><img src="images/bullet.jpg" width="220" height="190"></td>
<td height="200"><img src="images/dome.jpg" width="220" height="190"></td>
<td height="200"><img src="images/Pan Tilt Zoom Camera.jpg" width="220" height="190"></td>
<td height="200"><img src="images/hidden.jpg" width="220" height="190"></td></tr>


<tr>
<td align="center"><font color="white"><b>Bullet Camera</b></font></td>
<td align="center"><font color="white"><b>Dome Camera</b></font></td>
<td align="center"><font color="white"><b>Pan Tilt Zoom Camera</b></font></td>
<td align="center"><font color="white"><b>Hidden Camera</b></font></td>
</tr>

</table>

</div>
        


<div id="footer">

<img src="images/footer.png" width="990" height="200">

</div>

        	
                  </div>
</body>