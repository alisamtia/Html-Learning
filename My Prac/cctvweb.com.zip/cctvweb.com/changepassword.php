<?php

include_once("function.php");
	


if(!isset($_SESSION['newuser']))
	{
		header("Location: signup.php");
	}

if(!isset($_SESSION['registered']))
	{
		header("Location: signup.php");
	}

?>





<?php

if(isset($_POST["email"]))
{
	$cur = $_POST['curPass'];
	$email = $_POST['email'];
	$new = $_POST['newPass'];
	$cnew = $_POST['cnewPass'];
	
	mysql_query("UPDATE users SET pass='$new' WHERE username='$email'") or die(mysql_error());
header("Location: index.php");
}
	
?>
	








<br>
<br>
<script>
em=document.forms["c"]["e"].value
if(em=="")
{
document.getElementById("c").innerHTML="*Required"
}

cpa=document.forms["c"]["curpass"].value
if(em=="")
{
document.getElementById("r").innerHTML="*Required"
}

npa=document.forms["c"]["newpass"].value
if(npa=="")
{
document.getElementById("g").innerHTML="*Required"
}

cnpa=document.forms["c"]["cnewpass"].value
if(cnpa=="")
{
document.getElementById("j").innerHTML="*Required"
}

if(pa!==cpa)
{
document.getElementById("q").innerHTML="* Password Not Match"
}


</script>
<h1 align="center">Change Password:</h1>
<form action='' method='POST' name="c">
	<table align="center">
			<tr>
				<td>Email Address</td><td><input type='text' name='email' /><b id="c"></b></td>
			</tr>
            <tr>
				<td>Current Password: </td><td><input type='password' name='curPass' /><b id="r"></b></td>
			</tr>
			<tr>
				<td>New Password: </td><td><input type='password' name='newPass' /><b id="g"></b></td>
			</tr>
			<tr>
				<td>New Password: </td><td><input type='password' name='cnewPass' /><b id="j"></b><b id="q"></b></td>
			</tr>
			
            <tr>
				<td></td><td><input type='submit' value='Change Password' name='changePass' /></td>
			</tr>
		
	</table>
</form>

