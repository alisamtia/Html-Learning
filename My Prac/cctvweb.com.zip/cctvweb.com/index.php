<?php

include_once("function.php");
	


if(!isset($_SESSION['newuser']))
	{
		header("Location: signup.php");
	}

if(!isset($_SESSION['registered']))
	{
		header("Location: signup.php");
	}

?>






<!DOCTYPE>
<head>
<style>
#maindiv
{
width:990px;
height:1055px;
margin-left:auto;
margin-right:auto;
position:relative;
}



#banner{
width:980px;
height:150px;
position:absolute;

}

#menu{
width:750px;
height:40px;
position:absolute;

margin-top:40px;
margin-left:230px;
}


#slider{
width:990px;
height:400px;
position:absolute;
margin-top:120px;
}



#text1
{
width:990px;
height:290px;
text-align:justify;
position:absolute;
margin-top:560px;
}


#footer
{
width:990px;
height:200px;
position:absolute;
margin-top:855px;
margin-left:px;
}

</style>





<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <title>Amazing Slider</title>
    
    <!-- Insert to your webpage before the </head> -->
    <script src="sliderengine/jquery.js"></script>
    <script src="sliderengine/amazingslider.js"></script>
    <script src="sliderengine/initslider-1.js"></script>
    <!-- End of head section HTML codes -->
    


</head>

<body>
<div id="maindiv">
    

<div id="banner">


    <?php
	include("banner.php");
        
    ?>



    </div>


    	<div id="menu">


        <?php
	
include("menu.php");
    ?>
    
    	</div>
        
        <div id="slider">
        

<?php

	include("slider.html");

?>
    
    
    	</div>




<div id="text1">

<br>
<br>
On the Insert tab, the galleries include items that are designed to coordinate with the overall look of your document. You can use these galleries to insert tables, headers, footers, lists, cover pages, and other document building blocks. When you create pictures, charts, or diagrams, they also coordinate with your current document look.
You can easily change the formatting of selected text in the document text by choosing a look for the selected text from the Quick Styles gallery on the Home tab. You can also format text directly by using the other controls on the Home tab. Most controls offer a choice of using the look from the current theme or using a format that you specify directly.
To change the overall look of your document, choose new Theme elements on the Page Layout tab. To change the looks available in the Quick Style gallery, use the Change Current Quick Style Set command. Both the Themes gallery and the Quick Styles gallery provide reset commands so that you can always restore the look of your document to the original contained in your current template.
On the Insert tab, the galleries include items that are designed to coordinate with the overall look of your document. You can use these galleries to insert tables, headers, footers, lists, cover pages, and other document building blocks. When you create pictures, charts, or diagrams, they also coordinate with your current document look.
You can easily change the formatting of selected text in the document text by choosing a look for the selected text from the Quick Styles gallery on the Home tab. You can also format text directly by using the other controls on the Home tab. Most controls offer a choice of using the look from the current theme or using a format that you specify directly.
To change the overall look of your document, choose new Theme elements on the 


</div>
        




<div id="footer">
<img src="images/footer.png" width="990" height="200">
</div>

        	
                  </div>
</body>