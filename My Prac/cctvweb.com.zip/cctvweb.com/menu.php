

<style>
a#new:visited{
width:100px;
height:40px;
display:block;
background-color:black;
color:white;
font-weight:bold;
text-decoration:underline;
text-align:center;
line-height:40px;
}
#ul
{
list-style-type:none;
padding:0px;
margin:0px;

}
#li
{
float:left;
}
a#new:link
{
border-radius:10px 10px 10px 10px;
margin-left:0px;
border-left:solid red 2px;
width:100px;
height:40px;
display:block;
background-color:grey;
color:white;
text-decoration:none;
text-align:center;
line-height:40px;


background: -webkit-linear-gradient(red, blue); /* For Safari 5.1 to 6.0 */
    background: -o-linear-gradient(red, blue); /* For Opera 11.1 to 12.0 */
    background: -moz-linear-gradient(red, blue); /* For Firefox 3.6 to 15 */
    background: linear-gradient(skyblue, red); /* Standard syntax (must be last) */

font-weight:bold;

}
a#new:hover
{
border-radius:30px;

font-size:px;
width:100px;
height:40px;
display:block;
background-color:black;
color:white;
text-decoration:underline;
text-align:center;
line-height:40px;
font-weight:bold;
}
a#new:active
{
width:100px;
height:40px;
display:block;
background-color:green;
color:pink;
text-decoration:underline;
text-align:center;
line-height:40px;
}
</style>



<ul id="ul">
<li id="li">
<a href="index.php" id="new">Home</a>
</li>
<li id="li">
<a href="products.php" id="new">Products</a>
</li>
<li id="li">
<a href="aboutus.php" id="new">About us</a>
</li>
<li id="li">
<a href="signup.php" id="new">Registration</a>
</li>



</ul>

