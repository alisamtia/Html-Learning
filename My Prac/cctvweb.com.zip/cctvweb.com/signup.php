<?php 

	include_once("function.php");
$e='';
$p='';
$fn='';
$ln='';



$nmat='';


if(isset($_POST['username']) && isset($_POST['password']))
	{


$username = $_POST['username'];

$password = $_POST['password'];


$sql = "SELECT * FROM users WHERE username='$username' AND pass='$password'";


$query  = mysql_query($sql);


$num_rows = mysql_num_rows($query);


if($num_rows >= 1)

{


$_SESSION['registered'] = '';
$_SESSION['newuser'] = '';
			

	header("Location: index.php");
			
	
}

else
{
$_SESSION['dontexist'] = '';
$nmat='<b style="color:red">Password Not match</b>';
}
}
?>















	
<?php
if(isset($_POST['fname']))


{


$fname = $_POST['fname'];

$lname = $_POST['lname'];

$email = $_POST['email'];

$password = $_POST['password'];
$cpassword = $_POST['cpassword'];

$msg = $_POST['msg'];



$sql = "SELECT * FROM users WHERE username='$email'";
		


$query  = mysql_query($sql);

		
$num_rows = mysql_num_rows($query);

if($num_rows >= 1)

{

//alert('sdfsd');
$e='<b style="color:red;">Email alredy Exist</b>';

$_SESSION['user_exist'] = 'dfds';
}











$sql = "SELECT * FROM users WHERE pass='$password'";
		


$query  = mysql_query($sql);

		
$num_rows = mysql_num_rows($query);

if($num_rows >= 1)

{

//alert('sdfsd');
$p='<b style="color:red;">Password alredy Exist</b>';

$_SESSION['user_exist'] = 'dfds';
}

















$sql = "SELECT * FROM users WHERE fname='$fname'";
		


$query  = mysql_query($sql);

		
$num_rows = mysql_num_rows($query);

if($num_rows >= 1)

{

//alert('sdfsd');
$fn='<b style="color:red;">First Name alredy Exist</b>';

$_SESSION['user_exist'] = 'dfds';
}





$sql = "SELECT * FROM users WHERE lname='$lname'";
		


$query  = mysql_query($sql);

		
$num_rows = mysql_num_rows($query);

if($num_rows >= 1)

{

//alert('sdfsd');
$ln='<b style="color:red;">First Name alredy Exist</b>';

$_SESSION['user_exist'] = 'dfds';
}







else


{
			
$sql = "INSERT INTO users VALUES (NULL,'$fname','$lname','$email', '$password','$msg')";
			

mysql_query($sql);

$_SESSION['newuser'] = '';
			
$_SESSION['registered'] = '';
		
	header("Location: index.php");


}

}


?>
<!DOCTYPE>

<head>

<script>
function abc()
{
fname=document.forms["valid"]["fname"].value
if(fname=="")
{
alert("Please Fill First Name");
return false;
}


lname=document.forms["valid"]["lname"].value
if(lname=="")
{
alert("Please Fill Last Name");
return false;
}



email=document.forms["valid"]["email"].value
if(email=="")
{
alert("Please Fill Email Address");
return false;
}

password=document.forms["valid"]["password"].value
if(password=="")
{
alert("Please Fill Password");
return false;
}


cpassword=document.forms["valid"]["cpassword"].value
if(cpassword=="")
{
alert("Please Fill Confirm Password");
return false;
}

if(password!=cpassword)
{
alert("Your Password is Not Match!")
return false;
}
msg=document.forms["valid"]["msg"].value
if(msg=="")
{
alert("Type Your Message");
return false;
}




}
</script>


<style>
#maindiv
{
width:990px;
height:1295px;
margin-left:auto;
margin-right:auto;
position:relative;
}
#banner{
width:980px;
height:150px;
position:absolute;

}

#menu{
width:740px;
height:40px;
position:absolute;

margin-top:40px;
margin-left:230px;
}


#slider{
width:990px;
height:400px;
position:absolute;
margin-top:120px;
}



#signup
{
width:990px;
height:500px;
text-align:justify;
position:absolute;
margin-top:580px;
}






#footer
{
width:990px;
height:200px;
position:absolute;
margin-top:520px;
margin-left:0px;
}

</style>





<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <title>Amazing Slider</title>
    
    <!-- Insert to your webpage before the </head> -->
    <script src="sliderengine/jquery.js"></script>
    <script src="sliderengine/amazingslider.js"></script>
    <script src="sliderengine/initslider-1.js"></script>
    <!-- End of head section HTML codes -->
    


</head>

<body>
<div id="maindiv">
	
    <div id="banner">
    <?php
	include("banner.php");
        
    ?>
    </div>
    	<div id="menu">
        <?php
	
include("menu.php");
    ?>
    
    	</div>
        
        <div id="slider">
        

<?php
	include("slider.html");
    ?>
    
    
    	</div>




<div id="signup">



<div style="padding:40px;;margin-left:20px;position:absolute; border:10px solid black; width:450px; border-radius:20px;background-color:white">


<table width="435" height="200">
<form action="" method="post" name="valid">




<tr>

<td colspan="2" align="center">
<h1>New User</h1>
</td>

</tr>


<tr>

<td>First Name</td>
<td>
<input type="text" name="fname" size="35">
</td>
</tr>

<tr>
<td></td>
<td><?php echo $fn;?></td>
</tr>




<tr>

<td>
Last Name</td>

<td>
<input type="text" name="lname" size="35">
</td>
</tr>
<tr>
<td></td>
<td><?php echo $ln;?></td>
</tr>








<tr>

<td>Email Address</td>
<td>
<input type="text" name="email" size="35">
<span style="position:absolute; margin-left:px; margin-top:-17px;">
</td>
	</tr>
<tr>
<td></td>
<td><?php echo $e;?></td>
</tr>





<tr>

<td>Password</td>

<td>
<input type="password" name="password" id="" size="35">
<br>
</td>
</tr>

<tr>
<td></td>
<td><?php echo $p;?></td>
</tr>



<tr>

<td>Confirm Password</td>

<td><input type="password" name="cpassword" id="" size="35">
 <br>
    </td>
</tr>






<tr>

<td>Your Message</td>

<td>
<textarea cols="37" rows="7" name="msg"></textarea>
    </td>


</tr>




<tr>
	<td colspan="2" align="right"> 
	<input type="submit" value="Create Account" onClick="return(abc())">
	</td>
	</tr>
</form>
</table>


</div>
        




<div  style="height:365px;;padding:20px;position:absolute;background-color:white;border:11px solid black; margin-left:620px; border-radius:20px;">



<table height="130">

<tr>

<td align="center" colspan="2"><h3>Already Member<h3>
</td>

</tr>



<tr>

<form action="" method="post">
<tr>
<td colspan="2" align="center"><?php echo $nmat;?></td>
</tr>
<td>
Email Address
</td>
<td><input type="text" name="username"></td>
</tr>


<tr>
    <td>Password</td>
    <td><input type="password" name="password" id=""><b id="a"></b></td>
</tr>


<tr>
<td colspan="2" align="right">


<input type="submit" value="Login">
</td>
</tr>
</form>
</table>




<h5 align="right"><a href="changepassword.php">Change Password</a></h5>





</div>




<div id="footer">

<img src="images/footer.png" width="990" height="200">
</div>

</div>
</body>